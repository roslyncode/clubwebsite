import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

df = pd.read_csv('Community_Episodes_IMDb_Ratings.csv')
print(df.head())
df[['season','episode_number']] = df[['season','episode_number']].astype(str)
print(df.info())
print(df.describe())
print(df.groupby('season').describe())
print(df.sort_values('rating').head(10))
print(df.sort_values('rating',ascending=False).head(10))
print(df.groupby('season').mean()['rating'])
sns.set(font_scale=1.5,font='sans-serif',style='whitegrid')
plt.figure(figsize=(12,12))
sns.scatterplot(x=df.rating,y=df.total_votes,alpha=0.5,s=100)

plt.savefig('Episode Ratings Scatterplot.png',dpi=200)

df['episode_number'] = df['episode_number'].apply(lambda num: num.zfill(2))
df_heat = pd.pivot_table(data=df,index=['season'],columns=['episode_number'],values=['rating'])
episodenum = [*range(1,26)]
episodenum = [str(x) for x in episodenum]
seasonticks = [*range(1,7)]
seasonticks = ['Season '+str(x) for x in seasonticks]
sns.set_theme(font_scale=3,font='sans-serif',style='whitegrid')
plt.figure(figsize=(30,14))
fg = sns.heatmap(df_heat,cmap='coolwarm_r', cbar_kws={'orientation': 'horizontal', 'label': 'IMDb Rating'}, square=True)

# Moving the x-axis ticks and to the top
fg.xaxis.tick_top()
fg.set_xticklabels(episodenum,fontsize=30)
fg.set_yticklabels(seasonticks, rotation=360, horizontalalignment='right',fontsize=30)
# Adding more space between the y tick labels and the heatmap
fg.tick_params(axis='y', which='major', pad=25)
fg.set_ylabel('')    
fg.set_xlabel('')
fg.set_title('Community Episodes',fontname='sans-serif',fontsize=100,pad=100)

fig = fg.get_figure()
fig.savefig('Episode Ratings Heatmap.png',dpi=200)